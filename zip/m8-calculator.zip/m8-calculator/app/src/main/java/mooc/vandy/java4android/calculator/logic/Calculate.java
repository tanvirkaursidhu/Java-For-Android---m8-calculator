package mooc.vandy.java4android.calculator.logic;

public interface Calculate {
    //calculate interface is implemented by all classes
    //value1 is first argument
    //value2 is second argument
    void calculate(int value1,int value2);
}
